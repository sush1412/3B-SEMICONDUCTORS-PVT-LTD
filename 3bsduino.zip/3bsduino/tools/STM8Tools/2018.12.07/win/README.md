# Unix-like text utilities

These binaries are taken from the
[MinGW/MSys](http://www.mingw.org/wiki/MSYS) project. They bring some
Unix-like functionality to Windows systems.

All binaries are 32 bit versions.


## Usage

Include this directory in your `PATH` or move these file into a directory
that is already included in your path.
